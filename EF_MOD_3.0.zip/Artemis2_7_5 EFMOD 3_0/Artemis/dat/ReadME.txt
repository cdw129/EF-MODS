Copyright
These are reduced-volume sound files for Artemis Spaceship Bridge Simulator.
They belong ENTIRELY to
http://artemis.eochu.com

You may not use these in any way, except to replace the sound files of your legally purchased version of Artemis Spaceship Bridge Simulator, if you need quieter audio.

If you only want to reduce the startup sound file:
Artemis Main Screen.ogg

These files are found in and go in the Artemis\dat\ folder.